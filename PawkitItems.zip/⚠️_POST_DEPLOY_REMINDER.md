# ⚠️ POST-DEPLOYMENT REMINDER ⚠️

## 🚨 DO NOT DELETE THIS FILE UNTIL COMPLETED 🚨

---

## ✅ BEFORE Merge - Completed

- [x] Delete Den API routes
- [x] Update library filtering to use collections
- [x] Den migration created and tested
- [x] Pre-merge test suite (91% pass rate)
- [x] API validation bugs fixed
- [x] All core functionality verified

## 🎨 BEFORE Merge - UI Polish (In Progress)

- [ ] Re-enable settings menu (was disabled during UI overhaul)
- [ ] Unify tags area styling across views (Library vs Pawkits Overview)
- [ ] Fix right sidebar not working in some views
- [ ] Remove "Inbox" section from Home view (no longer needed)
- [ ] General UI consistency pass

---

## 📋 Immediate Post-Merge Tasks (Do Right After Merge)

### 1. Clean Up Test Pages
**These test pages should be removed from production:**

```bash
# Remove test pages (they're dev-only)
rm -rf app/(dashboard)/test/pre-merge-suite
rm -rf app/(dashboard)/test/sync-tests  
rm -rf app/(dashboard)/test-local-storage

# Or move to a /dev folder if you want to keep them
mkdir -p app/(dashboard)/dev
mv app/(dashboard)/test app/(dashboard)/dev/
```

**Why:** Test pages expose internal implementation details and aren't needed in production.

### 2. Remove Debug Console Logs (Optional)
Search for excessive logging:
```bash
# Search for debug logs
grep -r "console.log" lib/stores/data-store.ts lib/services/sync-service.ts

# Remove or comment out non-essential logs
# Keep error logs, remove debug spam like "extractAndSaveLinks" calls
```

### 3. Update Environment Variables
Verify production `.env` has:
```
NODE_ENV=production
NEXT_PUBLIC_APP_URL=https://your-domain.com
# (all other required vars)
```

---

## ⏳ WAIT 24-48 Hours After Production Deploy

**Then run this cleanup:**

### Step 1: Wait 24-48 Hours ⏰

Give users time to log in and verify their Den items migrated correctly.

### Step 2: Verify Migration Worked ✅

Check that:
- [ ] Users can see their old Den items
- [ ] Items are in a private pawkit called "The Den"
- [ ] No complaints about missing data
- [ ] No migration errors in logs

### Step 3: Run Cleanup Command 🧹

**Only after verification above**, run this in Claude Code:

```bash
claude-code "Remove all Den-related code: 1) Delete /api/den routes, 2) Remove Den references from components (especially the 404 error in card-detail-modal.tsx), 3) Remove Den from sidebar/navigation, 4) Remove the inDen field from future use (keep it in DB for now for safety, just stop using it in the app)."
```

---

## Why This Matters

The Den → Private Pawkit migration just ran. The old Den code is still in the app as a safety net. Once you verify the migration worked, you can safely remove the old code.

**If you remove the code too early and the migration failed, users lose access to their Den items!**

---

## 🧹 Additional Cleanup (After Den Verification)

### 4. Clean Up Duplicate Detection Logs (Optional)
The duplicate card detection is working but logging a lot. If it's too noisy:

```bash
claude-code "Reduce logging verbosity in lib/stores/data-store.ts for duplicate detection. Keep the warnings but remove excessive debug logs for deduplicateCards function."
```

### 5. Remove Link Extraction Spam (Optional)
The `extractAndSaveLinks` function is called excessively:

```bash
claude-code "Add debouncing to extractAndSaveLinks in data-store.ts. Use 500ms debounce so it only runs once when user stops typing, not on every keystroke."
```

### 6. Remove Test Data (If Any)
Check for any test data that might have been created:

```bash
# In production database, check for test data:
# SELECT * FROM "Card" WHERE title LIKE '%test%' OR url LIKE '%test%';
# SELECT * FROM "Collection" WHERE name LIKE '%test%';
# Delete test data if found
```

### 7. Monitor Error Logs
Check server logs for:
- ❌ Any 500 errors (should be fixed now)
- ❌ 404s for missing routes  
- ❌ Excessive duplicate detection warnings
- ✅ Verify sync is working smoothly

---

## 📊 Success Metrics to Track

After deployment, monitor:

1. **Zero Data Loss**
   - No user reports of missing cards/collections
   - Den migration successful (all items visible in "The Den")

2. **Multi-Session Detection Working**
   - Users see conflict warnings when editing same card
   - No simultaneous edit data loss

3. **Performance**
   - Sync completing in <5 seconds
   - No timeout errors
   - IndexedDB performing well

4. **Error Rate**
   - <1% 500 errors
   - <5% 400/422 validation errors
   - Zero critical errors

---

## When To Delete This File

✅ After you've completed:
- [ ] Immediate post-merge cleanup (test pages removed)
- [ ] 24-48 hour wait period
- [ ] Den cleanup (old code removed)
- [ ] Optional polish (logging, debouncing)
- [ ] Verified everything working in production
- [ ] No user complaints for 1 week  

---

**Deployment Date:** ___________ (fill this in when you deploy!)

**Verification Date:** ___________ (24-48 hours later)

**Cleanup Date:** ___________ (after verification passes)

---

## 🧹 Code Cleanup Tasks (After Merge & Deploy)

### Remove Test Pages
Once everything is verified working in production, clean up test pages:

```bash
claude-code "Remove test pages that were used for pre-merge validation: 1) Delete app/(dashboard)/test/pre-merge-suite/ directory, 2) Delete any other test pages in app/(dashboard)/test/ that aren't needed in production, 3) Keep only production-necessary test utilities. These were development-only tools."
```

**What to remove:**
- [ ] `/test/pre-merge-suite` - Comprehensive test suite (served its purpose)
- [ ] Any other `/test/*` pages that aren't needed for production monitoring

**What to keep (if exists):**
- Production health check pages
- User-facing diagnostic tools
- Any test pages users might need

### Update inDen Field Usage

After 1-2 weeks of Den cleanup running successfully:

```bash
claude-code "Final inDen cleanup: 1) Remove inDen field from Card model in prisma/schema.prisma, 2) Create migration to drop the column, 3) Remove any remaining inDen references in server code (lib/server/cards.ts, lib/server/collections.ts), 4) Clean up inDen from type definitions"
```

**Timeline:** 1-2 weeks after Den cleanup (only after confirming no issues)

### Performance Optimizations

Once stable in production, address minor issues:

```bash
claude-code "Add debouncing to extractAndSaveLinks function in lib/stores/data-store.ts. Currently being called excessively during card edits. Use 500ms debounce to reduce console spam and improve performance."
```

### Console Cleanup

```bash
claude-code "Review and clean up excessive console.log statements in: 1) lib/stores/data-store.ts (extractAndSaveLinks logs), 2) lib/services/sync-service.ts (sync coordination logs), 3) Keep only essential error logging and critical status updates"
```

---

**Created:** October 28, 2025
**Last Updated:** October 29, 2025
